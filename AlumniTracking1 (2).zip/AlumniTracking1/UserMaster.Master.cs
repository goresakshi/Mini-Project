﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
namespace AlumniTracking1
{
    public partial class UserMaster : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string conn = @"Data Source=LAPTOP-CGQQIECB\SQLEXPRESS;Initial Catalog=Alumnidata;Integrated Security=True";
            SqlConnection sql = new SqlConnection(conn);
            sql.Open();
            SqlCommand cmd = new SqlCommand("select * from ContactUs", sql);
            SqlDataReader dataReader = cmd.ExecuteReader();
            string email = "";
            string phoneNo = "";
            while(dataReader.Read())
            {
                email = email + dataReader[0];
                phoneNo = phoneNo + dataReader[1];
            }
            dataReader.Close();
            Label1.Text = "Email Us: "+ email;
            Label2.Text = "Call Us: "+ phoneNo;
        }
    }
}